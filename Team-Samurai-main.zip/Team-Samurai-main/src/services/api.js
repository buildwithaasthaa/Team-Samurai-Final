﻿```js
// ================================
// API CONFIGURATION
// ================================

// Local development:
// http://127.0.0.1:8000
//
// Production:
// VITE_API_BASE_URL=https://team-samurai-2xyn.onrender.com/api

const API_URL =
  import.meta.env.VITE_API_BASE_URL?.replace(/\/api$/, "") ||
  "http://127.0.0.1:8000";

console.log("API URL:", API_URL);

// ================================
// OFFLINE STORAGE
// ================================

import {
  saveOfflineData,
  getOfflineData,
} from "./offline";

// ================================
// RESPONSE HANDLER
// ================================

async function handleResponse(response) {
  let data = null;

  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (!response.ok) {
    const message =
      data?.message ||
      data?.detail ||
      `Backend error: ${response.status}`;

    throw new Error(message);
  }

  return data;
}

// ================================
// DASHBOARD
// ================================

export async function getDashboardData() {
  try {
    const response = await fetch(
      `${API_URL}/villages`
    );

    const villages =
      await handleResponse(response);

    const riskAssessment =
      Array.isArray(villages)
        ? villages
        : villages?.villages || [];

    const data = {
      total_villages:
        riskAssessment.length,

      risk_assessment:
        riskAssessment,
    };

    // Save latest successful data
    // for offline use
    saveOfflineData(
      "reloc8_dashboard",
      data
    );

    return data;

  } catch (error) {
    console.warn(
      "Backend unavailable. Using offline dashboard data."
    );

    const cached =
      getOfflineData(
        "reloc8_dashboard"
      );

    if (cached) {
      return cached;
    }

    throw error;
  }
}

// ================================
// HEALTH CHECK
// ================================

export async function getHealth() {
  try {
    const response = await fetch(
      `${API_URL}/health`
    );

    return await handleResponse(
      response
    );

  } catch (error) {
    console.warn(
      "Backend health check failed."
    );

    throw error;
  }
}

// ================================
// WEATHER
// ================================

export async function getWeather() {
  try {
    // Backend weather endpoint:
    // /api/weather
    const response = await fetch(
      `${API_URL}/api/weather`
    );

    const data =
      await handleResponse(response);

    // Save latest successful weather
    saveOfflineData(
      "reloc8_weather",
      data
    );

    return data;

  } catch (error) {
    console.warn(
      "Weather unavailable. Using cached weather."
    );

    const cached =
      getOfflineData(
        "reloc8_weather"
      );

    if (cached) {
      return cached;
    }

    throw error;
  }
}

// ================================
// SHELTERS
// ================================

export async function getShelters() {
  try {
    // Backend shelter endpoint:
    // /shelters
    const response = await fetch(
      `${API_URL}/shelters`
    );

    const data =
      await handleResponse(response);

    // Save latest successful shelter data
    saveOfflineData(
      "reloc8_shelters",
      data
    );

    return data;

  } catch (error) {
    console.warn(
      "Shelters unavailable. Using cached shelter data."
    );

    const cached =
      getOfflineData(
        "reloc8_shelters"
      );

    if (cached) {
      return cached;
    }

    throw error;
  }
}

// ================================
// RISK ASSESSMENT
// ================================

export async function calculateRisk(
  villages
) {
  if (!Array.isArray(villages)) {
    throw new Error(
      "Risk calculation requires a village array."
    );
  }

  try {
    const response = await fetch(
      `${API_URL}/risk`,
      {
        method: "POST",

        headers: {
          "Content-Type":
            "application/json",
        },

        body: JSON.stringify({
          villages: villages,
        }),
      }
    );

    const data =
      await handleResponse(response);

    // Save latest successful risk data
    saveOfflineData(
      "reloc8_risk",
      data
    );

    return data;

  } catch (error) {
    console.warn(
      "Risk API unavailable. Using cached risk data."
    );

    const cached =
      getOfflineData(
        "reloc8_risk"
      );

    if (cached) {
      return cached;
    }

    throw error;
  }
}

